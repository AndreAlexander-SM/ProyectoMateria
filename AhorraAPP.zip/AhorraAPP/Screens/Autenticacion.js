import { Text, StyleSheet, View} from 'react-native'

export default function AutenticacionUsuario(){

    return(
        <View>
            <Text>Autenticacion de Usuario</Text>
        </View>
    )
}

const styles = StyleSheet.create({})